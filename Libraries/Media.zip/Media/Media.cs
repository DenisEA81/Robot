﻿using System;
using System.Collections.Generic;
using System.IO;
using Graph2D;
/*
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Reflection;
 */

namespace Media
{
    
    

    #region PlayList
    /// <summary>
    /// Плейлист
    /// </summary>
    public class PlayList : List<string>
    {        
        /// <summary>
        /// Наименование плейлиста
        /// </summary>
        public string PlayListName = "";

        /// <summary>
        /// Тип плейлиста
        /// </summary>
        public MediaCommon.SFXType PlayListType;

        public PlayList(MediaCommon.SFXType Type = MediaCommon.SFXType.Music) : base()
        {
            PlayListType = Type;
        }
        ~PlayList()
        { }

        /// <summary>
        /// Загрузка списка из каталога по маске и количеству. Конечное имя файла будет fileMask+"_trc_"+(index)+"."+fileExt, где index = 0..fileCount.
        /// Перед добавлением имени файла в плейлист, проверяется его существование.
        /// </summary>
        /// <param name="fileMask">Путь и маска файла</param>
        /// <param name="fileCount">Количество файлов</param>
        /// <param name="fileExt">Расширение файлов</param>
        /// <param name="checkExists">Проверять существование файлов</param>
        public void LoadFromCatalogByNumber(string fileMask, int fileCount, string fileExt = "mp3", bool checkExists = true)
        {
            bool fAdd = true;
            string fName = "";
            PlayListName = Path.GetFileName(fileMask);
            for (int i = 0; i < fileCount; i++)
            {
                fAdd = true;
                fName = fileMask + "_trc_" + i.ToString() + "." + fileExt;
                if (checkExists) fAdd = File.Exists(fName);
                if (fAdd) Add(fName);
            }
        }
    }
    #endregion

    #region PlayListProfile
    /// <summary>
    /// Профиль плейлистов, состоящий из нескольких плейлистов, объединенных в общий профиль
    /// </summary>
    public class PlayListProfile : List<PlayList>
    {
        /// <summary>
        /// Имя профиля плейлистов. По умолчанию равен наименованию ini-файла, из которого загружается.
        /// </summary>
        public string ProfileName = "";
        /// <summary>
        /// Список плейлистов
        /// </summary>

        public PlayListProfile() : base()
        { }
        ~PlayListProfile()
        { }

        /// <summary>
        /// Поиск компонента по имени
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public int SearchByName(string name)
        {
            for (int i = 0; i < this.Count; i++)
                if (this[i].PlayListName == name) return i;
            throw new Exception("Компонент с именем <" + name + "> не найден.");
        }

        public PlayList this[string name]
        {
            get { return this[SearchByName(name)]; }
            set { this[SearchByName(name)] = value; }
        }

        /// <summary>
        /// Загрузка плейлистов по информации из ini-файла. Плейлисты находятся в том же каталоге.
        /// Структура ini-файла построчно представляет собою список перечисленных через ракзделитель параметров: 
        /// маска_имени_файла, количество_файлов_в_плейлисте, код_типа_плейлиста (перечень из PlayListInfo.PlayListType) 
        /// </summary>
        /// <param name="iniFileName">Путь и имя ini-файла</param>
        /// <param name="separatorList">Список допустимых разделителей. По умолчанию: знак табуляции</param>
        /// <param name="fileExt">Расширение файлов в плейлисте</param>
        public void LoadFromIni(string iniFileName, char[] separatorList = null, string fileExt = "mp3")
        {
            const int parameter_count = 3;
            if (!File.Exists(iniFileName)) throw new Exception("Не найден файл: " + iniFileName);
            if (separatorList == null) separatorList = new char[] { '\t' };
            string[] buff;
            string line = "";
            int counter = 0;
            int PlayListFileCount = 0;
            int plType = 0;

            #region Имя профиля из имени файла
            {
                string[] fSplitted = Path.GetFileName(iniFileName).Split('.');
                ProfileName = fSplitted[0];
                for (int i = 1; i < fSplitted.Length - 1; i++)
                    ProfileName += "." + fSplitted[i];
            }
            #endregion

            StreamReader iniFile = new StreamReader(iniFileName);
            try
            {
                while (!iniFile.EndOfStream)
                {
                    line = iniFile.ReadLine();
                    if (line.Trim() == "") continue;
                    counter++;
                    buff = line.Split(separatorList);
                    if (buff.Length < parameter_count) throw new Exception("Файл <" + iniFile + "> в строке №" + counter.ToString() + " содержит неверное количество параметров.");
                    if (!int.TryParse(buff[1], out PlayListFileCount)) throw new Exception("Файл <" + iniFile + "> в строке №" + counter.ToString() + " содержит некорректный первый параметр: " + buff[1]);
                    if (!int.TryParse(buff[2], out plType)) throw new Exception("Файл <" + iniFile + "> в строке №" + counter.ToString() + " содержит некорректный второй параметр: " + buff[2]);
                    if (PlayListFileCount < 0) throw new Exception("Файл <" + iniFile + "> в строке №" + counter.ToString() + " содержит некорректный первый параметр: " + buff[1] + ". Его значение не может быть меньше 0.");
                    if ((plType < 0) | (plType > 2)) throw new Exception("Файл <" + iniFile + "> в строке №" + counter.ToString() + " содержит некорректный второй параметр: " + buff[2] + ". Его значение не может быть меньше 0 и больше 2.");
                    Add(new PlayList((MediaCommon.SFXType)plType));
                    this[Count - 1].LoadFromCatalogByNumber(Path.GetDirectoryName(iniFileName) + "\\" + buff[0], PlayListFileCount, fileExt);
                }
            }
            finally
            {
                iniFile.Close();
            }
        }
    }
    #endregion

    #region PlayListProfileCollection
    /// <summary>
    /// Коллекция профилей плейлистов
    /// </summary>
    public class PlayListProfileCollection : List<PlayListProfile>
    {
        public PlayListProfileCollection() : base()
        { }

        ~PlayListProfileCollection()
        { }

        /// <summary>
        /// Поиск компонента по имени
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public int SearchByName(string name)
        {
            for (int i = 0; i < this.Count; i++)
                if (this[i].ProfileName == name) return i;
            throw new Exception("Компонент с именем <" + name + "> не найден.");
        }

        public PlayListProfile this[string name]
        {
            get { return this[SearchByName(name)]; }
            set { this[SearchByName(name)] = value; }
        }

        public void LoadFromIni(string iniFileName, char[] separatorList = null, string fileExt = "mp3")
        {
            if (!File.Exists(iniFileName)) throw new Exception("Не найден файл: " + iniFileName);
            string line = "";
            int counter = 0;

            StreamReader iniFile = new StreamReader(iniFileName);
            try
            {
                while (!iniFile.EndOfStream)
                {
                    line = iniFile.ReadLine().Trim();
                    if (line == "") continue;
                    counter++;
                    Add(new PlayListProfile());
                    this[Count - 1].LoadFromIni(Path.GetDirectoryName(iniFileName) + "\\" + line + "\\" + line + ".ini", separatorList, fileExt);
                }
            }
            finally
            {
                iniFile.Close();
            }
        }

        public PlayList GetPlayList(string profileName, string playlistName)
        {
            return this[profileName][playlistName];
        }
    }
    #endregion

    #region MediaCommon
    public static class MediaCommon
    {
        #region SFXMixingMode
        /// <summary>
        /// Режимы микширования звуков
        /// </summary>
        public enum SFXMixingMode
        {
            /// <summary>
            /// Вытеснение (замена)
            /// </summary>
            Supplant = 0,
            /// <summary>
            /// Блокирование (игнорирование)
            /// </summary>
            Blocking,
            /// <summary>
            /// Параллельное звучание
            /// </summary>
            Parallel
        }
        #endregion


        #region SFXType
        /// <summary>
        /// Типы плейлистов
        /// </summary>
        public enum SFXType
        {
            /// <summary>
            /// Музыка или музыкальное оповещение
            /// </summary>
            Music = 0,
            /// <summary>
            /// Ответы на команды пользователя
            /// </summary>
            UserCommand = 1,
            /// <summary>
            /// Голос и разовые звуки юнита
            /// </summary>
            UnitSoundSpeakNotify = 2
        }
        #endregion


        #region NonDuplicateList<>
        /// <summary>
        /// Список, исключающий дублирующие элементы
        /// </summary>
        /// <typeparam name="TList">Тип элемента</typeparam>
        public class NonDuplicateList<TList> : List<TList>
        {
            public NonDuplicateList() : base()
            { }

            ~NonDuplicateList()
            { }

            public new bool Add(TList item)
            {
                if (BinarySearch(item) >= 0) return false;
                base.Add(item);
                return true;
            }

            public new bool Insert(int index, TList item)
            {
                if (BinarySearch(item) >= 0) return false;
                base.Insert(index, item);
                return true;
            }
        }
        #endregion
    }
    #endregion
    
    #region GameMediaPlayer
    /// <summary>
    /// Игровой медиаплеер
    /// </summary>    
    public class GameMediaPlayer : System.Windows.Media.MediaPlayer
    {
        /// <summary>
        /// Опции воспроизведения
        /// </summary>
        public enum PlayOption { PlayAll = 0, PlayOneOnly = 1, LoopTrack = 2, LoopList = 3 }

        /*
        /// <summary>
        /// Список владельцев плеера (нужно заменить на список владельцев пула плееров. Это не стек плееров: стек плееров должен содержать список пулов плееров: Плеер -> Пул плееров -> Стек пулов плееров)
        /// </summary>
        public MediaCommon.NonDuplicateList<int> OwnerID { get; protected set; }
        */

        /// <summary>
        /// Пользовательское наименование проигрывателя
        /// </summary>
        public string PlayerName = "";

        /// <summary>
        /// Плейлист
        /// </summary>
        public PlayList PlayList = null;

        /// <summary>
        /// Текущий номер трека в плейлисте
        /// </summary>
        public int TrackNumber { get; protected set; } = 0;

        /// <summary>
        /// Опции воспроизведения
        /// </summary>
        public PlayOption Option = PlayOption.PlayAll;

        /// <summary>
        /// Признак воспроизведения в случайном порядке
        /// </summary>
        public bool RandomPlay = false;

        /// <summary>
        /// Время перерыва (в миллисекундах) между треками плейлиста для функции NonStop();
        /// </summary>
        /// 
        public int PlayListDelay
        {
            get { return _playListDelay; }
            set { _playListDelay = (value < 0) ? 0 : value; }
        }
        private int _playListDelay = 0;

        /// <summary>
        /// Пауза между треками для режима NonStop
        /// </summary>
        protected TimerTicker NonStopTrackDelayTicker = null;

        /// <summary>
        /// Показывает и задает громкость плеера (от 0% до 100%)
        /// </summary>
        public new int Volume { get { return (int)base.Volume * 100; } set { base.Volume = value / 100.0; } }

        /// <summary>
        /// Игровой медиаплеер
        /// </summary>
        /// <param name="file_name">Путь к файлу</param>
        /// <param name="volume">Громкость</param>
        /// <param name="play_now">Признак, запускать ли воспроизведение сразу</param>
        public GameMediaPlayer(string file_name, int volume = 100, bool play_now = true) : base()
        {
            Open(file_name);
            Volume = volume;
            if (play_now) Play();
            PlayList = new PlayList();
            PlayList.Add(file_name);
            TrackNumber = 0;
        }

        /// <summary>
        /// Создание игрового медиаплеера
        /// </summary>
        /// <param name="list">Список воспроизведения</param>
        /// <param name="volume">Громкость (0%-100%)</param>
        /// <param name="play_now">Признак немедленного воспроизведения</param>
        /// <param name="track_number">Номер текущего трека в плейлисте для воспроизведения</param>
        public GameMediaPlayer(PlayList list, int volume = 100, bool play_now = true, int track_number = 0) : base()
        {
            PlayList = list;
            PlayerName = list.PlayListName;         
            Volume = volume;
            if (list.Count > 0)
            {
                TrackNumber = track_number;
                Open(PlayList[TrackNumber]);
                if (play_now) Play();
            }
            else
                TrackNumber = 0;
        }

        /// <summary>
        /// Перезапуск воспроизведения текущего трека
        /// </summary>
        public void Replay()
        {
            Stop();
            Play();
        }

        /// <summary>
        /// Воспроизвести следующий трек согласно предустановленным опциям
        /// </summary>
        /// <param name="forcePlay">Признак быстрого воспроизведения (без предварительного Open) для режима LoopList с количеством треков в плейлисте равным 1. Корректно работает только если файл ранее уже был открыт.</param>
        /// <returns>false в случае остановки плейлиста</returns>
        public bool PlayNext(bool forcePlay = false)
        {
            if (PlayList.Count <= 0) return false;
            Stop();
            switch (Option)
            {
                case PlayOption.PlayOneOnly:
                    return false;
                case PlayOption.LoopTrack:
                    Play();
                    return true;
                case PlayOption.PlayAll:
                    if (RandomPlay) TrackNumber = new Random().Next(0, PlayList.Count);
                    else if ((++TrackNumber) >= PlayList.Count) return false;
                    Open(PlayList[TrackNumber]);
                    Play();
                    return true;
                case PlayOption.LoopList:
                    if (RandomPlay) TrackNumber = new Random().Next(0, PlayList.Count);
                    else if ((++TrackNumber) >= PlayList.Count) TrackNumber = 0;
                    if (!(forcePlay & (PlayList.Count == 1))) Open(PlayList[TrackNumber]);
                    Play();
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Статус воспроизведения
        /// </summary>
        /// <returns></returns>
        public bool isPlaying()
        {
            return Position < NaturalDuration;
        }

        /// <summary>
        /// Поддержка воспроизведения в режиме NonStop
        /// </summary>
        /// <returns>false в случае остановки плейлиста</returns>
        public bool NonStop()
        {
            if (Position >= NaturalDuration)
            {
                if (NonStopTrackDelayTicker == null)
                {
                    NonStopTrackDelayTicker = new TimerTicker(PlayListDelay);
                    NonStopTrackDelayTicker.Reset();
                }
                if (NonStopTrackDelayTicker.Check(false))
                {
                    NonStopTrackDelayTicker = null;
                    return PlayNext();
                }
            }
            return true;
        }

        public void Open(string file_name)
        {
            Open(new Uri(file_name.ToString(), System.UriKind.Relative));
        }
    }
    #endregion

    #region GameMediaPlayerStack
    /// <summary>
    /// Стек плееров
    /// </summary>
    public class GameMediaPlayerStack:List<GameMediaPlayer>
    {
        public MediaCommon.SFXMixingMode sfxMixingMode { get; protected set; }

        public int MaxLength { get; protected set; }
                
        public GameMediaPlayerStack(MediaCommon.SFXMixingMode mode, int max_length = 5):base()
        {
            if (max_length < 1) throw new Exception("Неверно указано значение параметра max_length.");
            sfxMixingMode = mode;
            MaxLength = max_length;
        }

        ~GameMediaPlayerStack()
        {}

        public void SetVolume(int volume)
        {
            for (int i = 0; i < Count; i++) this[i].Volume = volume;
        }

        /// <summary>
        /// Проверяет текущие проигрыватели и удаляет отыгравшие, либо переключает треки далее по плейлисту
        /// </summary>
        /// <returns>Возвращает оставшееся количество активных проигрывателей</returns>
        public int CheckPlay()
        {
            for (int i = 0; i < Count; i++)
                if (!this[i].NonStop())
                {
                    this[i].Close();
                    RemoveAt(i--);
                }
            return Count;
        }

        public int GetPlayerIndexByName(string name, bool throw_if_not_found = true)
        {
            for (int i = 0; i < Count; i++)
                if (this[i].PlayerName == name) return i;
            if (throw_if_not_found) throw new Exception("Компонент с именем <" + name + "> не найден");
            return -1;
        }

        private new void Add(GameMediaPlayer item) { throw new Exception("Вызван устаревший метод."); } // Скрываю базовый метод в внутрь класса


        public bool Add(PlayList list, int volume = 100, bool playNow = true,int track_number=0)
        {
            switch (sfxMixingMode)
            {
                case MediaCommon.SFXMixingMode.Blocking:
                    {
                        if (Count > 0) return false;
                        base.Add(new GameMediaPlayer(list, volume, playNow,track_number));
                        return true;
                    }
                case MediaCommon.SFXMixingMode.Supplant:
                    {
                        if (Count > 0) Remove(list);
                        base.Add(new GameMediaPlayer(list, volume, playNow, track_number));
                        return true;
                    }
                case MediaCommon.SFXMixingMode.Parallel:
                    {
                        if (Count >= MaxLength) return false;
                        base.Add(new GameMediaPlayer(list, volume, playNow, track_number));
                        return true;
                    }
            }
            return false;
        }

        public bool Remove(PlayList list)
        {
            switch (sfxMixingMode)
            {
                case MediaCommon.SFXMixingMode.Supplant:
                case MediaCommon.SFXMixingMode.Blocking:
                    {
                        if (Count <= 0) return false;
                        if (sfxMixingMode == MediaCommon.SFXMixingMode.Supplant) this[0].Stop();
                        this[0].Close();
                        Clear();
                        return true;
                    }
                case MediaCommon.SFXMixingMode.Parallel:
                    {
                        if (Count <= 0) return false;
                        int index = GetPlayerIndexByName(list.PlayListName);
                        this[index].Stop();
                        this[index].Close();
                        RemoveAt(index);
                        return true;
                    }
            }
            return false;
        }
    }
    #endregion


    /// <summary>
    /// Управление игровым аудио
    /// </summary>
    public class GameAudio
    {
        public PlayListProfileCollection PlayListCollection = null;
        public List<GameMediaPlayerStack> Player = null;

        #region Специфичные настройки для конкретного приложения
        /// <summary>
        /// Громкость звуков и музыки
        /// </summary>
        public int[] PlayerStackVolume { get; protected set; } = new int[] { 100, 100, 100 };
        
        public static class SFXName_Profile
        {
            public static string Music = "music";
            public static string Fauna = "fauna";
            public static string Villy = "villy";
        }

        public static class SFXName_Villy
        {
            public const string MoveCommand = "Villy_Move_Command";
            public const string AutoGun = "Villy_AutoGun";
            //public const string MoveStep = "Villy_Move_Step";
        }

        public static class SFXIndex_PlayerStackType
        {
            public static int Music = 0;
            public static int UserCommand = 1;
            public static int UnitSoundSpeakNotify = 2;
        }

        public static class SFXIndex_PlayListProfile
        {
            public static int Music;
            public static int Fauna;
            public static int Villy;
        }        

        public static class SFXIndex_Villy
        {
            public static int CommandGo;          
            public static int AutoGun;
            //  public static int Step;
        }
        #endregion


        public GameAudio(int max_player_count_in_stack, string playListCollectionIniFileName)
        {            
            #region Медиаплееры: три стека по типу звуков
            Player = new List<GameMediaPlayerStack>();
            Player.Add(new GameMediaPlayerStack(MediaCommon.SFXMixingMode.Blocking, max_player_count_in_stack)); //Music
            Player.Add(new GameMediaPlayerStack(MediaCommon.SFXMixingMode.Supplant, max_player_count_in_stack)); //UserCommand
            Player.Add(new GameMediaPlayerStack(MediaCommon.SFXMixingMode.Parallel, max_player_count_in_stack)); //UnitSoundSpeakNotify
            #endregion

            #region Плейлисты: по источнику звука
            PlayListCollection = new PlayListProfileCollection();
            PlayListCollection.LoadFromIni(playListCollectionIniFileName);
            #endregion

            #region Индексация плейлистов
            SFXIndex_PlayListProfile.Music = PlayListCollection.SearchByName(SFXName_Profile.Music);
            SFXIndex_PlayListProfile.Fauna = PlayListCollection.SearchByName(SFXName_Profile.Fauna);
            SFXIndex_PlayListProfile.Villy = PlayListCollection.SearchByName(SFXName_Profile.Villy);
            
            SFXIndex_Villy.CommandGo = PlayListCollection[SFXIndex_PlayListProfile.Villy].SearchByName(SFXName_Villy.MoveCommand);            
            SFXIndex_Villy.AutoGun = PlayListCollection[SFXIndex_PlayListProfile.Villy].SearchByName(SFXName_Villy.AutoGun);
            //SFXIndex_Villy.Step = PlayListCollection[SFXIndex_PlayListProfile.Villy].SearchByName(SFXName_Villy.MoveStep);
            #endregion
        }

        public void CloseAll()
        {
            if (Player != null)
            {
                for (int i = 0; i < Player.Count; i++)
                {
                    if (Player[i] != null)
                        for (int j = 0; j < Player[i].Count; j++)
                        {
                            Player[i][j].Close();
                            Player[i].RemoveAt(j--);
                        }
                }
            }
        }

        ~GameAudio()
        {}

        public void UpdatePlayerVolume()
        {
            if (Player != null)
            {
                if (Player[SFXIndex_PlayerStackType.Music] != null) Player[SFXIndex_PlayListProfile.Music].SetVolume(PlayerStackVolume[SFXIndex_PlayerStackType.Music]);
                if (Player[SFXIndex_PlayerStackType.UnitSoundSpeakNotify] != null) Player[SFXIndex_PlayerStackType.UnitSoundSpeakNotify].SetVolume(PlayerStackVolume[SFXIndex_PlayerStackType.UnitSoundSpeakNotify]);
                if (Player[SFXIndex_PlayerStackType.UserCommand] != null) Player[SFXIndex_PlayerStackType.UserCommand].SetVolume(PlayerStackVolume[SFXIndex_PlayerStackType.UserCommand]);
            }
        }

        public void Reset(int MusicPlayListIndex, int volumeMusic = 100, int volumeCommand = 100, int volumeSound = 100)
        {
            PlayerStackVolume[SFXIndex_PlayerStackType.Music] = volumeMusic;
            PlayerStackVolume[SFXIndex_PlayerStackType.UserCommand] = volumeCommand;
            PlayerStackVolume[SFXIndex_PlayerStackType.UnitSoundSpeakNotify] = volumeSound;

            CloseAll();

            Player[SFXIndex_PlayerStackType.Music].Clear();
            AddSound(SFXIndex_PlayerStackType.Music, SFXIndex_PlayListProfile.Music, MusicPlayListIndex);
        }

        /// <summary>
        /// Добавление звука
        /// </summary>
        /// <param name="idxPlayerStackType"></param>
        /// <param name="idxPlayListProfile"></param>
        /// <param name="track_number"></param>
        public void AddSound(int idxPlayerStackType, int idxPlayListProfile, int idxPlayListNumber, int track_number = -1)
        {
            if (track_number<0) track_number = new Random().Next(0, PlayListCollection[idxPlayListProfile][idxPlayListNumber].Count);
            Player[idxPlayerStackType].Add(PlayListCollection[idxPlayListProfile][idxPlayListNumber], PlayerStackVolume[idxPlayerStackType], true, track_number);
            switch (idxPlayerStackType)
            {
                case 0: //SFXIndex_PlayerStackType.Music
                    Player[idxPlayerStackType][Player[idxPlayerStackType].Count - 1].Option = GameMediaPlayer.PlayOption.LoopList;
                    break;
                case 1:// SFXIndex_PlayerStackType.UserCommand
                    Player[idxPlayerStackType][Player[idxPlayerStackType].Count - 1].Option = GameMediaPlayer.PlayOption.PlayOneOnly;
                    break;
                case 2:// SFXIndex_PlayerStackType.UnitSoundSpeakNotify
                    Player[idxPlayerStackType][Player[idxPlayerStackType].Count - 1].Option = GameMediaPlayer.PlayOption.PlayOneOnly;
                    break;
            }
        }


        /// <summary>
        /// Проверяет текущие проигрыватели и удаляет отыгравшие, либо переключает треки далее по плейлисту
        /// </summary>
        /// <returns></returns>
        public void CheckPlay()
        {
            for (int i = 0; i < Player.Count; i++) Player[i].CheckPlay();
        }
    }
}