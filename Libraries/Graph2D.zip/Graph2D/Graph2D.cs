﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;

namespace Graph2D
{
    public abstract class Matrix
    {
        /// <summary>
        /// Количество строк
        /// </summary>
        public int RowCount { get; protected set; } = 0;

        /// <summary>
        /// Количество колонок
        /// </summary>
        public int ColCount { get; protected set; } = 0;

        /// <summary>
        /// Создание матрицы
        /// </summary>
        /// <param name="row_count">Количество строк</param>
        /// <param name="col_count">Количество колонок</param>
        public Matrix(int row_count, int col_count)
        {
            RowCount = row_count;
            ColCount = col_count;
            CreateMatrixBuffer();
        }

        /// <summary>
        /// Выделение памяти под буфер
        /// </summary>
        protected abstract void CreateMatrixBuffer();

        /// <summary>
        /// Освобождение памяти из под буфера
        /// </summary>
        protected abstract void DestroyMatrixBuffer();

        /// <summary>
        /// Выдает индекс в матрице по номеру строки и столбца
        /// </summary>
        /// <param name="row">номер строки</param>
        /// <param name="col">номер столбца</param>
        /// <returns></returns>
        public int Index(int row, int col)
        {
            if ((row < 0) | (col < 0) | (row >= RowCount) | (col >= ColCount)) throw new Exception("Неверно заданы индексы строки или столбца.");
            return col * RowCount + row;
        }

        /// <summary>
        /// Деструктор класса
        /// </summary>
        ~Matrix()
        {
            DestroyMatrixBuffer();
        }
    }


    /// <summary>
    /// Матрица спрайтов
    /// </summary>
    public class BitMapMatrix : Matrix
    {
        public int SizeWidth = 0;
        public int SizeHeight = 0;
        public string MatrixName = "";

        /// <summary>
        /// Карта спрайтов 
        /// </summary>
        public Bitmap[] Map { get; protected set; } = null;

        /// <summary>
        /// Создание пустой матрицы спрайтов заданной размерности
        /// </summary>
        /// <param name="matrix_name">Имя матрицы</param>
        /// <param name="row_count">Количество строк матрицы</param>
        /// <param name="col_count">Количество колонок матрицы</param>
        public BitMapMatrix(string matrix_name, int row_count, int col_count) : base(row_count, col_count)
        {
            MatrixName = matrix_name;
        }

        protected override void CreateMatrixBuffer()
        {
            if (RowCount * ColCount <= 0) throw new Exception("Задано неверное количество столбцов или строк.");
            Map = new Bitmap[RowCount * ColCount];
        }

        protected override void DestroyMatrixBuffer()
        {
            Map = null;
        }
    }

    public class BitMapMatrixList:List<BitMapMatrix>
    {
        public string MatrixListName = "";

        public BitMapMatrixList(string name):base()
        {
            MatrixListName = name;
        }

        public BitMapMatrixList(int capacity) :base(capacity)
        { }

        public BitMapMatrixList(IEnumerable<BitMapMatrix> collection) : base(collection)
        { }

        public int SearchByMatrixName(string matrixName, bool throw_if_not_found = true)
        {
            for (int i = 0; i < Count; i++)
                if (this[i].MatrixName.ToUpper().Equals(matrixName.ToUpper())) return i;
            if (throw_if_not_found) throw new Exception("Элемент <" + matrixName + "> не найден.");
            return -1;
        }

        public BitMapMatrix this[string name]
        {
            get { return this[SearchByMatrixName(name)]; }
            set { this[SearchByMatrixName(name)] = value; }
        }

        public void LoadBitMapMatrixList(string fileDir, string iniName,char delimiter = '\t')
        {
            string iniFileName = fileDir + iniName;
            string spriteFileName = "";
            BitMapMatrix tmpMatrix = null;
            int RowCount = 0;
            int ImageSize = 0;
            int ColCount = 0;
            int lineIndex = 0;

            if (File.Exists(iniFileName))
            {
                StreamReader ini = new StreamReader(iniFileName);
                try
                {
                    string[] buff = null;

                    while (!ini.EndOfStream)
                    {
                        #region Чтение строки
                        lineIndex++;
                        string line = ini.ReadLine();
                        if (line.Trim() == "") continue;
                        buff = line.Split(delimiter);
                        #endregion

                        #region Проверка корректности строки
                        if (buff.Length != 4) throw new Exception("Неверный формат строки №" + lineIndex.ToString() + " (задано неверное количество параметров, либо использован некорректный разделитель) в файле <" + iniFileName + ">");
                        if (!(int.TryParse(buff[1], out ColCount) & int.TryParse(buff[2], out RowCount) & int.TryParse(buff[3], out ImageSize))) throw new Exception("Неверный формат строки №" + lineIndex.ToString() + " (задан некорректный параметр) в файле <" + iniFileName + ">");
                        #endregion

                        tmpMatrix = new BitMapMatrix(buff[0],RowCount, ColCount);
                        tmpMatrix.SizeHeight = tmpMatrix.SizeWidth = ImageSize;
                        

                        for (int c = 0; c < ColCount; c++)
                            for (int r = 0; r < RowCount; r++)
                            {
                                spriteFileName = fileDir + buff[0] + "_p" + c.ToString() + "_v" + r.ToString() + ".png";
                                if (System.IO.File.Exists(spriteFileName))
                                {
                                    tmpMatrix.Map[tmpMatrix.Index(r, c)] = new Bitmap(spriteFileName);

                                    if (tmpMatrix.Map[tmpMatrix.Index(r, c)].Width != ImageSize) throw new Exception("Ширина загруженного файла не совпадает с заданным для данного типа спрайтов. Требуемая ширина: " + ImageSize.ToString() + ", файл: " + spriteFileName);
                                    if (tmpMatrix.Map[tmpMatrix.Index(r, c)].Height != ImageSize) throw new Exception("Высота загруженного файла не совпадает с заданным для данного типа спрайтов. Требуемая высота: " + ImageSize.ToString() + ", файл: " + spriteFileName);
                                }
                                else
                                    throw new Exception("Не найден файл <" + spriteFileName + ">");
                            }
                        Add(tmpMatrix);
                    }
                }
                finally
                {
                    ini.Close();
                }
            }
            else throw new Exception("Не найден файл <" + iniFileName + ">");
        }        
    }

    public class BitMapMatrixListCollection:List<BitMapMatrixList>
    {
        public BitMapMatrixListCollection(string ApplicationDirectory, string imageCollectionFileName/*, char delimiter = '\t'*/) : base()
        {
            ReloadAllMatrix(ApplicationDirectory, imageCollectionFileName);//, delimiter);
        }

        public BitMapMatrixListCollection(int capacity) :base(capacity)
        { }

        public BitMapMatrixListCollection(IEnumerable<BitMapMatrixList> collection) : base(collection)
        { }


        public void ReloadAllMatrix(string ApplicationDirectory, string imageCollectionFileName)//, char delimiter = '\t')
        {
            #region Загрузка матриц
            {
                string imageCommonPath = Path.GetDirectoryName(ApplicationDirectory + imageCollectionFileName);
                if (!File.Exists(ApplicationDirectory + imageCollectionFileName)) throw new Exception("Файл <" + ApplicationDirectory + imageCollectionFileName + "> не найден.");

                StreamReader fStream = new StreamReader(ApplicationDirectory + imageCollectionFileName);
                try
                {
                    while (!fStream.EndOfStream)
                    {
                        string line = fStream.ReadLine();
                        if (line.Trim() == "") continue;
                        //string[] buff = line.Split(delimiter);
                        //if (buff.Length != 2) throw new Exception("Неверный формат строки в файле " + ApplicationDirectory + imageCollectionFileName);

                        Add(new BitMapMatrixList(line));
                        this[Count - 1].LoadBitMapMatrixList(imageCommonPath + "\\" + line + "\\", line + ".ini");
                        Application.DoEvents();
                    }
                }
                finally
                {
                    fStream.Close();
                }
            }
            #endregion            
        }

        public int SearchByMatrixListName(string matrixListName, bool throw_if_not_found = true)
        {
            for (int i = 0; i < Count; i++)
                if (this[i].MatrixListName.ToUpper().Equals(matrixListName.ToUpper())) return i;
            if (throw_if_not_found) throw new Exception("Элемент <"+matrixListName+"> не найден.");
            return -1;
        }

        public BitMapMatrixList this[string name]
        {
            get { return this[SearchByMatrixListName(name)]; }
            set { this[SearchByMatrixListName(name)] = value; }
        }
    }

    /// <summary>
    /// Простой спрайтовый юнит
    /// </summary>
    public class SpriteUnit
    {
        /// <summary>
        /// Ссылка на список матриц спрайтов
        /// </summary>
        public BitMapMatrixList MatrixList { get; protected set; } = null;

        /// <summary>
        /// Индекс активной матрицы
        /// </summary>
        public int ActiveMatrixIndex
        {
            get { return _activeMatrixIndex; }
            set
            {
                if ((value >= 0) & (value < MatrixList.Count))
                    _activeMatrixIndex = value;
                else
                    throw new Exception("Задано некорректное значение свойства ActiveMatrixIndex");
            }
        }
        protected int _activeMatrixIndex = 0;

        /// <summary>
        /// Позиция юнита
        /// </summary>
        public PointF Position
        {
            get { return _position; }
            protected set { _position = value; }
        }
        protected PointF _position = new Point(0, 0);


        /// <summary>
        /// Фаза действия
        /// </summary>
        public Phase phase { get; protected set; } = null;


        /// <summary>
        /// Вариант изображения
        /// </summary>
        public int Variant
        {
            get { return variant; }
            set
            {
                if ((value >= 0) & (value < MatrixList[_activeMatrixIndex].RowCount))
                    variant = value;
                else
                    throw new Exception("Задано некорректное значение для свойства Variant.");
            }
        }
        private int variant = 0;


        /// <summary>
        /// Создание спрайтового юнита
        /// </summary>
        public SpriteUnit(BitMapMatrixList matrixList)
        {
            MatrixList = matrixList;
            phase = new Phase(MatrixList[_activeMatrixIndex].ColCount);
            Variant = 0;
        }

        // Деструктор
        ~SpriteUnit()
        { }

        /// <summary>
        /// Перемещение в указанную область
        /// </summary>
        /// <param name="new_x">Новое значение X</param>
        /// <param name="new_y">Новое значение Y</param>
        public void MoveTo(int new_x, int new_y)
        {
            _position.X = new_x;
            _position.Y = new_y;
        }

        /// <summary>
        /// Перемещение юнита на указанное смещение
        /// </summary>
        /// <param name="dX">Смещение по X</param>
        /// <param name="dY">Смещение по Y</param>
        public void Move(float dX, float dY)
        {
            _position.X += dX;
            _position.Y += dY;
        }

        /// <summary>
        /// Возвращает спрайт, соответствующий текущей фазе и варианту
        /// </summary>
        /// <returns></returns>
        public Bitmap GetCurrentSprite()
        {
            return MatrixList[_activeMatrixIndex].Map[MatrixList[_activeMatrixIndex].Index(Variant, phase.currentPhase)];
        }

        /// <summary>
        /// Активная матрица
        /// </summary>
        /// <returns></returns>
        public BitMapMatrix GetActiveMatrix()
        {
            return MatrixList[_activeMatrixIndex];
        }

        /// <summary>
        /// Переход к следующему варианту
        /// </summary>
        public void NextVariant()
        {
            if ((MatrixList[_activeMatrixIndex].RowCount - 1) > variant) variant++; else variant = 0;
        }

        /// <summary>
        /// Переход к предыдущему варианту
        /// </summary>
        public void PreviousVariant()
        {
            if (variant > 0) variant--; else variant = (MatrixList[_activeMatrixIndex].RowCount - 1);
        }
    }

    /// <summary>
    /// Игровой спрайтовый юнит
    /// </summary>
    public class GameUnit : SpriteUnit
    {        
        /// <summary>
        /// Признак выбора юнита
        /// </summary>
        public bool Selected = false;

        private TimerTicker ActionStepTimer = null;

        /// <summary>
        /// Направление взгляда (углы в градусах)
        /// </summary>
        public float DirectionAngle { get; protected set; }

        /// <summary>
        /// Цель перемещения юнита
        /// </summary>
        public Point TargetPoint = new Point(0, 0);

        /// <summary>
        /// Скорость перемещения
        /// </summary>
        public float Speed = 0;

        /// <summary>
        /// Номер состояния юнита
        /// </summary>
        public int UnitStateIndex = 0;
        
        /// <summary>
        /// Игровой спрайтовый юнит
        /// </summary>
        /// <param name="matrix">Список матриц спрайтов(фазы и варианты)</param>
        /// <param name="internal_timer_delay">Интервал внутреннего таймера действий (0-не применять)</param>
        /// <param name="seek_timer">Смещение предустановленного времени вперед (в миллисекундах)</param>
        public GameUnit(BitMapMatrixList matrixList, int internal_timer_delay = 0, int seek_timer = 0) : base(matrixList)
        {
            ActionStepTimer = new TimerTicker(internal_timer_delay);
            ActionStepTimer.Seek(seek_timer);
        }

        /// <summary>
        /// Переход к следующему состоянию фазы с использованием внутреннего таймера
        /// </summary>
        /// <param name="reset">Признак, указывающий на необходимость автоматического сброса счетчика, если прошло заданное время после последнего сброса.</param>
        /// <returns>Номер текущей фазы</returns>
        public int Next(bool reset = true)
        {
            if (ActionStepTimer.Check(reset)) return phase.Next(); else return phase.currentPhase;
        }


        /// <summary>
        /// Продолжить движение в текущем направлении
        /// </summary>
        /// <param name="calculate_distance">Признак необходимости расчета дистанции до цели</param>
        /// <returns>Дистанция до цели либо 0 (в зависимости от признака)</returns>
        public int ActionDo_Move(bool calculate_distance = true)
        {
            float dx = -Speed * (float)Math.Sin(DirectionAngle * GameUtils.Radian);
            float dy = -Speed * (float)Math.Cos(DirectionAngle * GameUtils.Radian);
            Move(dx, dy);
            if (calculate_distance)
                return (int)GameUtils.Distance(Position, TargetPoint);
            else return 0;
        }

        public void SetAction(int state_index, bool cyclic_phase = true)
        {
            ActiveMatrixIndex = state_index;
            this.phase.Start(MatrixList[_activeMatrixIndex].ColCount, cyclic_phase);
            if (Variant > MatrixList[_activeMatrixIndex].RowCount) Variant = 0;
            UnitStateIndex = state_index;
        }
        
        /// <summary>
        /// Выбрать вариант через поворот юнита. Угол 0 отсчитывается против часовой стрелки от 12 часов.
        /// </summary>
        /// <param name="new_angle">Угол, в градусах</param>
        public void RotateVariant(float new_angle)
        {
            float anglePerVariant = (float)360 / MatrixList[_activeMatrixIndex].RowCount;
            new_angle %= 360;
            if (new_angle < 0) new_angle += 360;
            if (new_angle < 0) new_angle = 0; // подстраховка от неточностей машинного вычисления
            Variant = (int)(new_angle / anglePerVariant);
            DirectionAngle = new_angle;
        }
    }


    public class GameUnitList:List<GameUnit>
    {
        public string UnitListName = "";
        public GameUnitList(string list_name = ""):base()
        {
            UnitListName = list_name;
        }

        public GameUnitList(int capacity):base(capacity)
        {}

        public GameUnitList(IEnumerable<GameUnit> collection) :base(collection)
        {}

        /// <summary>
        /// Добавление юнита
        /// </summary>
        /// <param name="image_matrix_list">Ссылка на список матриц bitmap, хранящий матрицы спрайтов (фазы и варианты) всех действий данного юнита</param>
        /// <param name="matrix_index">номер матрицы спрайтов по умолчанию</param>
        /// <param name="X">абсолютная X-координата юнита</param>
        /// <param name="Y">абсолютная Y-координата юнита</param>
        /// <param name="timer_delay">задержка между кадрами, мс</param>
        /// <param name="timer_seek">отсрочка перед первым изменением начального кадра</param>
        /// <param name="PhaseStart">Признак, указывающий на необходимость немедленно запустить анимацию</param>
        /// <param name="PhaseCyclic">Признак, указывающий на цикличность анимации</param>
        public void Add(BitMapMatrixList image_matrix_list, int matrix_index, int X = 0,int Y = 0, int timer_delay = 0, int timer_seek = 0, bool PhaseStart = true, bool PhaseCyclic = true)
        {
            Add(new GameUnit(image_matrix_list, timer_delay, timer_seek));            
            this[Count - 1].ActiveMatrixIndex = matrix_index;
            this[Count - 1].MoveTo(X,Y);
            if(PhaseStart) this[Count - 1].phase.Start(PhaseCyclic);
        }
    }

    public class GameUnitListCollection:List<GameUnitList>
    {        
        public GameUnitListCollection():base()
        { }

        public GameUnitListCollection(int capacity):base(capacity)
        { }

        public GameUnitListCollection(IEnumerable<GameUnitList> collection) :base(collection)
        { }

        public int GetIndexByName(string name, bool throw_if_not_found = true)
        {
            for (int i = 0; i < Count; i++)
                if (this[i].UnitListName.ToUpper().Equals(name.ToUpper())) return i;
            if (throw_if_not_found) throw new Exception("Не найден элемент коллекции: "+name);
            return -1;
        }

        public GameUnitList this[string name]
        {
            get { return this[GetIndexByName(name)]; }
            set { this[GetIndexByName(name)] = value; }
        }        
    }

    /// <summary>
    /// Набор общих методов для игровых ситуаций
    /// </summary>
    public static class GameUtils
    {
        public const float Radian = (float)Math.PI / 180;

        /// <summary>
        /// Вычисление расстояния между двумя точками на плоскости
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static float Distance(PointF a, PointF b)
        {
            return (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }

        /// <summary>
        /// Расчет угла между нормализованными векторами
        /// </summary>
        /// <param name="vector0">первый вектор</param>
        /// <param name="vector1">второй вектор</param>
        /// <returns></returns>
        public static float GetAngleVector(PointF vector0, PointF vector1)
        {
            float cosAngle = (vector0.X * vector1.X + vector0.Y * vector1.Y);
            return (vector1.X < 0) ? (float)Math.Acos(cosAngle) / Radian : 360 - (float)Math.Acos(cosAngle) / Radian;
        }

        /// <summary>
        /// Нормализация вектора
        /// </summary>
        /// <param name="vector">вектор</param>
        /// <returns></returns>
        public static void NormalizeVector(ref PointF vector)
        {
            float viR = (float)Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y);
            viR = (viR < 0.001) ? float.MaxValue : 1 / viR;
            vector.X *= viR;
            vector.Y *= viR;
        }


        /// <summary>
        /// Определяет вхождение точки в прямоугольную область
        /// </summary>
        /// <param name="point">Точка</param>
        /// <param name="rect">Прямоугольник</param>
        /// <returns></returns>
        public static bool PointInRectangle(PointF point, Rectangle rect)
        {
            return !((point.X < rect.Left) | (point.X > rect.Right) | (point.Y < rect.Top) | (point.Y > rect.Bottom));
        }

        /// <summary>
        /// Определяет вхождение точки в прямоугольную область
        /// </summary>
        /// <param name="X">X-координата точки</param>
        /// <param name="Y">Y-координата точки</param>
        /// <param name="rect">Прямоугольник</param>
        /// <returns></returns>
        public static bool PointInRectangle(float X, float Y, Rectangle rect)
        {
            return !((X < rect.Left) | (X > rect.Right) | (Y < rect.Top) | (Y > rect.Bottom));
        }

        /// <summary>
        /// Определяет, пересекаются ли прямоугольники (входит ли один в другой)
        /// </summary>
        /// <param name="R1"></param>
        /// <param name="R2"></param>
        /// <returns></returns>
        public static bool RectIntersect(Rectangle R1, Rectangle R2)
        {
            return R1.IntersectsWith(R2);
        }

        /// <summary>
        /// Поиск точек пересечения линии, заданной отрезком P1-P2, с прямоугольником rect.  
        /// </summary>
        /// <param name="P1">Начальная точка отрезка</param>
        /// <param name="P2">Конечная точка отрезка</param>
        /// <param name="rect">Прямоугольник, с которым ищем пересечение</param>
        /// <param name="Intersect">Точки пересечения с ребрами в следующем порядке: левое, правое, верхнее, нижнее</param>
        /// <returns>Если отрезок имеет длину менее 1, то возвращает значение false</returns>
        public static bool LineIntersectRectangle(PointF P1, PointF P2, RectangleF rect, ref PointF[] Intersect)
        {
            float dX = P2.X - P1.X;
            float dY = P2.Y - P1.Y;
            if ((Math.Abs(dX) < 1) & (Math.Abs(dY) < 1)) return false;

            Intersect = new PointF[4];

            #region Левая грань 
            Intersect[0].X = rect.Left;
            Intersect[0].Y = (Math.Abs(dY) < 1) ? P1.Y : ((Math.Abs(dX) < 1) ? int.MaxValue : dY * (rect.Left - P1.X) / dX + P1.Y);
            #endregion

            #region Правая грань 
            Intersect[1].X = rect.Right;
            Intersect[1].Y = (Math.Abs(dY) < 1) ? P1.Y : ((Math.Abs(dX) < 1) ? int.MaxValue : dY * (rect.Right - P1.X) / dX + P1.Y);
            #endregion

            #region Верхняя грань 
            Intersect[2].Y = rect.Top;
            Intersect[2].X = (Math.Abs(dX) < 1) ? P1.X : ((Math.Abs(dY) < 1) ? int.MaxValue : dX * (rect.Top - P1.Y) / dY + P1.X);
            #endregion

            #region Нижняя грань 
            Intersect[3].Y = rect.Bottom;
            Intersect[3].X = (Math.Abs(dX) < 1) ? P1.X : ((Math.Abs(dY) < 1) ? int.MaxValue : dX * (rect.Bottom - P1.Y) / dY + P1.X);
            #endregion

            return true;
        }

        public static bool Between(float value, float min, float max)
        {
            return (value >= min) & (value <= max);
        }

        public static bool Between(int value, int min, int max)
        {
            return (value >= min) & (value <= max);
        }

        /// <summary>
        /// Функция сравнения двух элементов по их индексам
        /// </summary>
        /// <param name="idx1">первый индекс</param>
        /// <param name="idx2">второй индекс</param>
        /// <returns>-1 - первый элемент больше, 1 - второй элемент больше, 0 - равны </returns>
        public delegate int CompareFunction(int idx1, int idx2);
        private static void PartSort(ref int[] PointIndex, ref CompareFunction cmpFunc, int startIDX, int finishIDX, SortDirection order)
        {
            int j;
            int idx = startIDX;
            if (finishIDX == -1) finishIDX = PointIndex.Length;

            for (int i = startIDX; i < finishIDX - 1; i++)
            {
                idx = i;
                for (j = i + 1; j < finishIDX; j++)
                {
                    //if (unit[PointIndex[idx]].ScreenPosition.Z < unit[PointIndex[j]].ScreenPosition.Z) idx = j;
                    if (cmpFunc(PointIndex[idx], PointIndex[j]) == (order == SortDirection.Desc ? 1 : -1)) idx = j;
                }


                if (idx != i)
                {
                    j = PointIndex[i];
                    PointIndex[i] = PointIndex[idx];
                    PointIndex[idx] = j;
                }
            }
        }

        public enum SortDirection { Asc = 0, Desc = 1 }
        public static void Sort(ref int[] PointIndex, ref CompareFunction cmpFunc, SortDirection order = SortDirection.Asc)
        {
            // алгоритм быстрой сортировки с дроблением исходного массива

            // сортирую по группам
            int groupStep = (int)Math.Pow(PointIndex.Length, 0.6);
            if (groupStep < 5) groupStep = 5;

            int idx1 = 0;
            int idx2 = 0;
            int groupCount = (int)Math.Floor((float)(PointIndex.Length / groupStep)) + 1;
            int[] groupTop = new int[groupCount];
            int groupIndex = 0;
            while (idx1 < PointIndex.Length)
            {
                idx2 = idx1 + groupStep;
                if (idx2 > PointIndex.Length) idx2 = PointIndex.Length;
                groupTop[groupIndex++] = idx2 - idx1;
                PartSort(ref PointIndex, ref cmpFunc, idx1, idx2, order);
                idx1 += groupStep;
            }

            idx1 = -1;
            idx2 = -1;

            // собираю из групп
            if (PointIndex.Length > groupStep)
            {
                bool AllEmpty = true;
                int[] StackBuff = new int[PointIndex.Length];

                { // ищу первый миниимальный столбик
                    idx1 = 0;
                    for (int i = 1; i < groupCount; i++)
                    {
                        if (groupTop[i] <= 0) continue;

                        //if (unit[PointIndex[i * groupStep + groupTop[i] - 1]].ScreenPosition.Z < unit[PointIndex[idx1 * groupStep + groupTop[idx1] - 1]].ScreenPosition.Z) idx1 = i;
                        if (cmpFunc(PointIndex[i * groupStep + groupTop[i] - 1], PointIndex[idx1 * groupStep + groupTop[idx1] - 1]) == (order == SortDirection.Desc ? 1 : -1)) idx1 = i;




                    }
                }

                groupIndex = 0;
                bool setIdx = false;
                while (true)
                {
                    AllEmpty = true;
                    // ищу второй минимальный столбик
                    idx2 = -1;
                    for (int i = 0; i < groupCount; i++)
                    {
                        if (groupTop[i] <= 0) continue;
                        AllEmpty = false;
                        if (i == idx1) continue;
                        setIdx = (idx2 == -1);
                        //if (!setIdx) setIdx = (unit[PointIndex[i * groupStep + groupTop[i] - 1]].ScreenPosition.Z < unit[PointIndex[idx2 * groupStep + groupTop[idx2] - 1]].ScreenPosition.Z);
                        if (!setIdx) setIdx = (cmpFunc(PointIndex[i * groupStep + groupTop[i] - 1], PointIndex[idx2 * groupStep + groupTop[idx2] - 1]) == (order == SortDirection.Desc ? 1 : -1));


                        if (setIdx) idx2 = i;
                    }
                    if (AllEmpty) break;
                    if (idx2 == -1) idx2 = idx1;

                    // Выгружаю часть минимального столбика
                    int dx1 = idx1 * groupStep - 1;
                    int dx2 = idx2 * groupStep - 1;
                    bool f = false;
                    while (groupTop[idx1] > 0)
                    {
                        //if (unit[PointIndex[dx1 + groupTop[idx1]]].ScreenPosition.Z <= unit[PointIndex[dx2 + groupTop[idx2]]].ScreenPosition.Z)
                        if (order == SortDirection.Desc)
                            f = (cmpFunc(PointIndex[dx1 + groupTop[idx1]], PointIndex[dx2 + groupTop[idx2]]) >= 0);
                        else
                            f = (cmpFunc(PointIndex[dx1 + groupTop[idx1]], PointIndex[dx2 + groupTop[idx2]]) <= 0);

                        if (f)
                        {
                            StackBuff[groupIndex++] = PointIndex[dx1 + groupTop[idx1]];
                            groupTop[idx1]--;
                        }
                        else break;
                    }
                    idx1 = idx2;
                }

                // переписываем обратно в стек значения из временного буфера 
                idx2 = PointIndex.Length - 1;
                for (idx1 = 0; idx1 < PointIndex.Length;) PointIndex[idx1++] = StackBuff[idx2--];

            }
        }

        public static Cursor LoadCustomCursor(string path)
        {
            IntPtr hCurs = LoadCursorFromFile(path);
            if (hCurs == IntPtr.Zero) throw new Win32Exception("Не удалось загрузить курсор");
            var curs = new Cursor(hCurs);
            // Note: force the cursor to own the handle so it gets released properly
            var fi = typeof(Cursor).GetField("ownHandle", BindingFlags.NonPublic | BindingFlags.Instance);
            fi.SetValue(curs, true);
            return curs;
        }
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr LoadCursorFromFile(string path);
    }


    /// <summary>
    /// Управление выделением области
    /// </summary>
    public class GameUnitSelection
    {
        /// <summary>
        /// Начальная точка выделения
        /// </summary>
        public Point BeginPosition = new Point();

        /// <summary>
        /// Конечная точка выделения
        /// </summary>
        public Point EndPosition = new Point();
        /// <summary>
        /// Признак активности выделения
        /// </summary>
        public bool Active = false;

        /// <summary>
        /// Смещение линий выделения юнита
        /// </summary>
        public int SelectorDotOffset
        {
            get
            {
                if (_selectorDotOffset > 10) _selectorDotOffset = 0;
                return _selectorDotOffset++;
            }
        }
        private int _selectorDotOffset = 0;

        /// <summary>
        /// Признак события двойного щелчка мыши (для выделения только одного юнита)
        /// </summary>
        public bool DoubleClickSelect
        {
            get
            {
                if (_doubleClickSelect)
                {
                    _doubleClickSelect = false;
                    return true;
                }
                return false;
            }
            set
            {
                _doubleClickSelect = value;
            }
        }
        private bool _doubleClickSelect = false;

        public GameUnitSelection()
        { }

        /// <summary>
        /// Текущий прямоугольник выбора
        /// </summary>
        /// <returns></returns>
        public Rectangle CurrentSelection()
        {
            return new Rectangle((BeginPosition.X < EndPosition.X) ? BeginPosition.X : EndPosition.X, (BeginPosition.Y < EndPosition.Y) ? BeginPosition.Y : EndPosition.Y, Math.Abs(EndPosition.X - BeginPosition.X), Math.Abs(EndPosition.Y - BeginPosition.Y));
        }
    }



    #region Класс Фазы действия
    /// <summary>
    /// Фазы выполнения действия
    /// </summary>
    public class Phase
    {
        private bool Cyclic = false;

        /// <summary>
        /// Количество шагов действия
        /// </summary>
        public int phaseCount { get; private set; } = 1;

        /// <summary>
        /// Номер текущей фазы
        /// </summary>
        public int currentPhase { get; set; } = 0;

        /// <summary>
        /// Проверка статуса работы
        /// </summary>
        public bool completed { get; protected set; } = false;


        /// <summary>
        /// Фазы выполнения действия
        /// </summary>
        /// <param name="phase_count">Количество шагов</param>
        /// <param name="cyclic">Признак цикличности действия</param>
        public Phase(int phase_count = 1, bool cyclic = false)
        {
            Start(phase_count, cyclic);
        }

        /// <summary>
        /// Запуск действия
        /// </summary>
        /// <param name="phase_count">Количество шагов</param>
        /// <param name="cyclic">Признак цикличности действия</param>
        public void Start(int phase_count = 1, bool cyclic = false)
        {
            if (phase_count < 1) throw new Exception("Phase:Start() - неверно указано количество фаз.");
            phaseCount = phase_count;
            currentPhase = 0;
            completed = false;
            Cyclic = cyclic;
        }

        /// <summary>
        /// Запуск действия
        /// </summary>
        /// <param name="cyclic">Признак цикличности действия</param>
        public void Start(bool cyclic)
        {
            Start(phaseCount, cyclic);
        }

        /// <summary>
        /// Переход к следующему состоянию
        /// </summary>
        /// <returns></returns>
        public int Next()
        {
            currentPhase++;
            if (currentPhase >= phaseCount)
            {
                if (Cyclic) currentPhase = 0;
                else
                {
                    currentPhase = phaseCount - 1;
                    completed = true;
                }
            }
            return currentPhase;
        }
    }
    #endregion

    #region Класс Счетчик времени
    /// <summary>
    /// Счетчик времени
    /// </summary>
    public class TimerTicker
    {
        private long lastDTicks = 0;
        private int deltaMillisecond = 0;
        private const int TickByMillisecond = 10000;

        /// <summary>
        /// Счетчик времени
        /// </summary>
        /// <param name="delta">Дельта времени счетчика в миллисекундах</param>
        public TimerTicker(int delta)
        {
            deltaMillisecond = (delta > 0) ? delta : 0;
            lastDTicks = DateTime.Now.Ticks;
        }

        /// <summary>
        /// Сброс счетчика
        /// </summary>
        /// <param name="delta">Дельта времени счетчика в миллисекундах (не меняется если не указать)/param>
        public void Reset(int delta = -1)
        {
            if (delta >= 0) deltaMillisecond = delta;
            lastDTicks = DateTime.Now.Ticks;
        }

        /// <summary>
        /// Смещение запомненного времени
        /// </summary>
        /// <param name="delta">Смещение в миллисекундах</param>
        public void Seek(int delta)
        {
            lastDTicks += delta * TickByMillisecond;
        }

        /// <summary>
        /// Определяет, прошло ли заданное время после последнего сброса счетчика.
        /// </summary>
        /// <param name="reset">Признак, указывающий на необходимость автоматического сброса счетчика, если прошло заданное время после последнего сброса.</param>
        /// <returns></returns>
        public bool Check(bool reset = true)
        {
            bool tmp = (DateTime.Now.Ticks - lastDTicks) / TickByMillisecond > deltaMillisecond;
            if (tmp & reset) Reset();
            return tmp;
        }
    }
    #endregion



    /// <summary>
    /// Игровая область
    /// </summary>
    public class GameArea
    {
        /// <summary>
        /// Глобальный размер области
        /// </summary>
        public Size AreaSize
        {
            get { return _areaSize; }
            protected set { _areaSize = value; }
        }
        protected Size _areaSize;

        /// <summary>
        /// Размер рабочей области
        /// </summary>
        public Size WorkWindowSize
        {
            get { return _workWindowSize; }
            protected set { _workWindowSize = value; }
        }
        protected Size _workWindowSize;

        /// <summary>
        /// Смещение рабочего окна относительно верхнего левого угла всей глобальной области
        /// </summary>
        public Point WorkWindowOffset
        {
            get { return _workWindowOffset; }
            protected set { _workWindowOffset = value; }
        }
        protected Point _workWindowOffset;

        /// <summary>
        /// Смещение рабочей области относительно верхнего левого угла устройства вывода
        /// </summary>
        public Point ScreenOffset
        {
            get { return _screenOffset; }
            set { _screenOffset = value; }
        }
        protected Point _screenOffset;

        /// <summary>
        /// Представление рабочего окна
        /// </summary>
        public Rectangle WorkWindow
        {
            get
            {
                return new Rectangle(_workWindowOffset, _workWindowSize);
            }
        }


        /// <summary>
        /// Создание игровой области
        /// </summary>
        /// <param name="width">Ширина</param>
        /// <param name="height">Высота</param>
        public GameArea(int width, int height)
        {
            Resize(width, height);
        }

        /// <summary>
        /// Изменение размеров игровой области. Так же сбрасываются все рабочие окна и отступы.
        /// </summary>
        /// <param name="width">Ширина</param>
        /// <param name="height">Высота</param>
        public void Resize(int width, int height)
        {
            AreaSize = new Size(width, height);
            WorkWindowSize = new Size((Point)AreaSize);
            WorkWindowOffset = new Point(0, 0);
            ScreenOffset = new Point(0, 0);
        }

        /// <summary>
        /// Изменение размеров рабочего окна 
        /// </summary>
        /// <param name="width">Ширина</param>
        /// <param name="height">Высота</param>
        /// <param name="check_position">Учитывать текущую позицию рабочего окна относительно глобальных координат</param>
        /// <returns>false, если заданные размеры превышают размеры уровня</returns>
        public bool ResizeWorkWindow(int width, int height, bool check_position = true)
        {
            if ((width <= 0) | (height <= 0) | (((check_position ? _workWindowOffset.X : 0) + width) > AreaSize.Width) | ((check_position ? _workWindowOffset.Y : 0) + height > AreaSize.Height)) return false;
            _workWindowSize.Width = width;
            _workWindowSize.Height = height;
            return true;
        }

        /// <summary>
        /// Смещение рабочего окна 
        /// </summary>
        /// <param name="dx">Смещение по оси Х</param>
        /// <param name="dy">Смещение по оси Y</param>
        /// <param name="dock">Признак, указывающий следует ли смещать рабочее окно вплотную к краю уровня, если смещение на указанную величину невозможно.</param>
        /// <returns>true, если достигнут край уровня</returns>
        public bool MoveWorkWindow(int dx, int dy, bool dock = true)
        {
            bool res = false;

            if (_workWindowOffset.X + dx < 0)
            {
                res = true;
                if (dock) dx = -_workWindowOffset.X;
            }
            if (_workWindowOffset.Y + dy < 0)
            {
                res = true;
                if (dock) dy = -_workWindowOffset.Y;
            }
            if (_workWindowSize.Width + _workWindowOffset.X + dx > AreaSize.Width)
            {
                res = true;
                if (dock) dx = AreaSize.Width - _workWindowSize.Width - _workWindowOffset.X;
            }
            if (_workWindowSize.Height + _workWindowOffset.Y + dy > AreaSize.Height)
            {
                res = true;
                if (dock) dy = AreaSize.Height - _workWindowSize.Height - _workWindowOffset.Y;
            }
            _workWindowOffset.X += dx;
            _workWindowOffset.Y += dy;
            return res;
        }

        /// <summary>
        /// Конвертирование экранных координат в глобальные координаты всей области
        /// </summary>
        /// <param name="mouseX">X-координата мыши</param>
        /// <param name="mouseY">Y-координата мыши</param>
        /// <returns></returns>
        public Point ConvertMousePosToGlobal(int mouseX, int mouseY)
        {
            return new Point(mouseX - _screenOffset.X + _workWindowOffset.X, mouseY - _screenOffset.Y + _workWindowOffset.Y);
        }


        /// <summary>
        /// Конвертирование глобальных координат в координаты устройства (экранные)
        /// </summary>
        /// <param name="globalX">Глобальная X-координата</param>
        /// <param name="globalY">Глобальная Y-координата</param>
        /// <returns></returns>
        public Point ConvertGlobalPosToDevice(int globalX, int globalY)
        {
            return new Point(globalX - _workWindowOffset.X + _screenOffset.X, globalY - _workWindowOffset.Y + _screenOffset.Y);
        }

        /// <summary>
        /// Глобальное смещение по X (перевод с глобальных координат в экранные)
        /// </summary>
        /// <param name="globalX">Глобальная X-координата</param>
        /// <returns></returns>
        public int GlobalOffset_X(int globalX = 0)
        {
            return globalX + _screenOffset.X - _workWindowOffset.X;
        }

        /// <summary>
        /// Глобальное смещение по Y (перевод с глобальных координат в экранные)
        /// </summary>
        /// <param name="globalY">Глобальная Y-координата</param>
        /// <returns></returns>
        public int GlobalOffset_Y(int globalY = 0)
        {
            return globalY + _screenOffset.Y - _workWindowOffset.Y;
        }

        /// <summary>
        /// Глобальное смещение по (перевод с глобальных координат в экранные)
        /// </summary>
        /// <returns></returns>
        public Point GlobalOffset()
        {
            return new Point(_screenOffset.X - _workWindowOffset.X, _screenOffset.Y - _workWindowOffset.Y);
        }
    }


    /*
    /// <summary>
    /// Управление выводом 2D-графики
    /// </summary>
    public class GameGraphics
    {        
        #region Нижний слой - подложка (почва, пол)
        public const int backgroundImageSize = 256; // Размер спрайта подложки. Задается явно, так как для быстрого отображения нужно знать количество спрайтов в ширину и высоту по карте.
        private List<BitMapMatrix> backgroundMatrixList = null; // список матриц фоновых спрайтов
        private GameUnit[] backgroundMap = null; // карта 
        private int backgroundMatrixIndex = 1; // активный индекс матрицы спрайтов в списке (в текущем релизе на экране отображается одновременно только 1 матрица фона, так как нет конструктора уровней)

        private TimerTicker backgroundTimer = null;
        private int backgroundTimerDelay = 250;
        #endregion

        #region Растительность
        private List<BitMapMatrix> plantMatrixList = null; // список матриц спрайтов растений       
        private GameUnit[] plantUnit = null; // список растений на экране
        private int plantCount = 5; // количество растений на экране
        private int plantTimerDelay = 100;
        #endregion

        #region Юниты
        private List<BitMapMatrix> personMatrixList = null; // список матриц спрайтов юнитов       
        private int[] personActionIndexList = new int[] { 0, 1, 2 }; // список индексов действий для списка матриц спарйтов 
        private GameUnit[] personUnit = null; // список юнитов на экране
        private int personCount = 20; // количество юнитов на экране
        private int personTimerDelay = 50;
        public int personSpeed = 5; // скорость персонажа        
        private GameUnitSelection unitSelection = new GameUnitSelection(); // Выбор юнитов
        #endregion

        #region Указатели цели
        private List<BitMapMatrix> targetPointerMatrixList = null; // список матриц спрайтов указателей цели
        private List<GameUnit> targetPointer = null; // список целей на экране
        private int targetPointerDelay = 30;
        #endregion

        public GameGraphics()
        {
            #region Спрайты и тайлы
            {
                #region Загрузка фона
                //LabelCaption.Text = "Загрузка: фон...";
                Application.DoEvents();
                LoadBitMapMatrixList(ref backgroundMatrixList, ApplicationDirectory + "GameResources\\images\\terrain\\", "terrain.ini", backgroundImageSize, backgroundImageSize);
                #endregion

                #region Загрузка растений
                //LabelCaption.Text = "Загрузка: растения...";
                Application.DoEvents();
                LoadBitMapMatrixList(ref plantMatrixList, ApplicationDirectory + "GameResources\\images\\plant\\", "plant.ini");
                #endregion

                #region Загрузка юнитов
                //LabelCaption.Text = "Загрузка: юниты...";
                Application.DoEvents();
                LoadBitMapMatrixList(ref personMatrixList, ApplicationDirectory + "GameResources\\images\\villy\\", "villy.ini");
                #endregion

                #region Загрузка растений
                //LabelCaption.Text = "Загрузка: указатели целей...";
                Application.DoEvents();
                LoadBitMapMatrixList(ref targetPointerMatrixList, ApplicationDirectory + "GameResources\\images\\target\\", "target.ini");
                #endregion
            }
            #endregion
        }
    }       
    */
}
